import unittest
from collections.abc import Iterable, Iterator, Sequence
from dataclasses import replace
from itertools import product
from typing import override

from verify import ANCHORS, DAY, OFFSET_LIMIT, Anchor, Point, Preferences, Schedule


def normalize(points: Iterable[Point], anchors: Iterable[Anchor]) -> Schedule:
    points = tuple(points)
    anchors = tuple(anchors)
    if not points or len(anchors) != len(ANCHORS):
        raise ValueError("A cycle needs points and two anchors")
    if any(type(point.source_day) is not int for point in points):
        raise ValueError("Source dates must use whole days")
    if len({point.key for point in points}) != len(points):
        raise ValueError("Each point identity must occur once in a cycle")
    for cut in range(len(points)):
        rotated = points[cut:] + tuple(
            replace(point, source_day=point.source_day + 1) for point in points[:cut]
        )
        dates = [
            {point.source_day for point in rotated if point.basis == name}
            for name in ANCHORS
        ]
        if any(len(group) > 1 for group in dates):
            continue
        normalized_anchors = tuple(
            replace(anchor, source_day=next(iter(group), anchor.source_day))
            for anchor, group in zip(anchors, dates, strict=True)
        )
        normalized_points = tuple(
            point if point.basis == "Clock" else replace(point, source_day=0)
            for point in rotated
        )
        try:
            return Schedule(normalized_points, normalized_anchors)
        except ValueError:
            continue
    raise ValueError("The dated point order has no feasible repeating placement")


def stored_points(schedule: Schedule) -> tuple[Point, ...]:
    return tuple(
        point
        if point.basis == "Clock"
        else replace(
            point, source_day=schedule.anchors[ANCHORS.index(point.basis)].source_day
        )
        for point in schedule.points
    )


def anchor_time(
    schedule: Schedule, name: str, source_day: int, preferences: Preferences
) -> int:
    index = ANCHORS.index(name)
    cycle = source_day - schedule.anchors[index].source_day
    return cycle * DAY + schedule.resolve(cycle, preferences)[index]


def point_time(
    schedule: Schedule, key: str, source_day: int, preferences: Preferences
) -> int:
    point = next(point for point in schedule.points if point.key == key)
    if point.basis == "Clock":
        return source_day * DAY + point.minute
    return anchor_time(schedule, point.basis, source_day, preferences) + point.minute


def occurrence_bounds(point: Point, anchors: Sequence[Anchor]) -> tuple[int, int]:
    if point.basis == "Clock":
        time = point.source_day * DAY + point.minute
        return time, time
    anchor = anchors[ANCHORS.index(point.basis)]
    start = point.source_day * DAY + point.minute
    if not anchor.automatic:
        return start + anchor.clock, start + anchor.clock
    return start, start + DAY - 1


def insertion_orders(
    others: Sequence[Point], selected: Point, target: int, anchors: Sequence[Anchor]
) -> Iterator[tuple[Point, ...]]:
    if not others:
        yield (selected,)
        return
    for index, before in enumerate(others):
        after = others[(index + 1) % len(others)]
        before_minimum, _ = occurrence_bounds(before, anchors)
        _, after_maximum = occurrence_bounds(after, anchors)
        if index + 1 == len(others):
            after_maximum += DAY
        first_cycle = -((after_maximum - target - 1) // DAY)
        last_cycle = (target - before_minimum - 1) // DAY
        for cycle in range(first_cycle, last_cycle + 1):
            earlier = tuple(
                replace(point, source_day=point.source_day + cycle - 1)
                for point in others[index + 1 :]
            )
            later = tuple(
                replace(point, source_day=point.source_day + cycle)
                for point in others[: index + 1]
            )
            yield earlier + later + (selected,)


def placement_candidates(
    points: Sequence[Point],
    anchors: Sequence[Anchor],
    selected: Point,
    target: int,
    preferences: Preferences,
) -> list[Schedule]:
    points = tuple(points)
    anchors = tuple(anchors)
    if type(target) is not int or type(selected.source_day) is not int:
        raise ValueError("Placement uses whole clock minutes and source dates")
    if points:
        normalize(points, anchors)
    others = tuple(point for point in points if point.key != selected.key)
    if selected.basis == "Clock":
        selected = replace(selected, minute=target % DAY, source_day=target // DAY)
        offsets = (selected.minute,)
    elif selected.basis in ANCHORS:
        offsets = range(-OFFSET_LIMIT, OFFSET_LIMIT + 1)
    else:
        raise ValueError("Unknown point basis")
    result = []
    seen = set()
    for order in insertion_orders(others, selected, target, anchors):
        for offset in offsets:
            candidate = (*order[:-1], replace(order[-1], minute=offset))
            try:
                schedule = normalize(candidate, anchors)
            except ValueError:
                continue
            if (
                point_time(schedule, selected.key, selected.source_day, preferences)
                != target
            ):
                continue
            signature = (schedule.points, schedule.anchors)
            if signature not in seen:
                seen.add(signature)
                result.append(schedule)
    return result


def place(
    points: Sequence[Point],
    anchors: Sequence[Anchor],
    selected: Point,
    target: int,
    preferences: Preferences,
) -> Schedule:
    points = tuple(points)
    if type(target) is not int or type(selected.source_day) is not int:
        raise ValueError("Placement uses whole clock minutes and source dates")
    start = normalize(points, anchors) if points else None
    original = next((point for point in points if point.key == selected.key), None)
    if start is not None and original is not None and original.basis == selected.basis:
        if point_time(start, selected.key, selected.source_day, preferences) == target:
            return normalize(
                tuple(
                    replace(point, kelvin=selected.kelvin)
                    if point.key == selected.key
                    else point
                    for point in points
                ),
                anchors,
            )
    candidates = placement_candidates(points, anchors, selected, target, preferences)
    if not candidates:
        raise ValueError("No valid placement reaches the requested minute")
    if selected.basis == "Clock":
        return candidates[0]
    if start is not None:
        reference = anchor_time(start, selected.basis, selected.source_day, preferences)
    else:
        anchor = anchors[ANCHORS.index(selected.basis)]
        value = (
            preferences(selected.basis, selected.source_day)
            if anchor.automatic
            else None
        )
        reference = selected.source_day * DAY + (
            anchor.clock if value is None else value
        )

    def distance(schedule: Schedule) -> tuple[int, int]:
        time = anchor_time(schedule, selected.basis, selected.source_day, preferences)
        point = next(point for point in schedule.points if point.key == selected.key)
        return abs(time - reference), point.minute

    return min(candidates, key=distance)


def reanchor(
    points: Sequence[Point],
    anchors: Sequence[Anchor],
    key: str,
    basis: str,
    today: int,
    preferences: Preferences,
) -> Schedule:
    if basis not in ANCHORS or type(today) is not int:
        raise ValueError("Anchor changes need a daily anchor and a whole local date")
    original = normalize(points, anchors)
    selected = next((point for point in original.points if point.key == key), None)
    if selected is None or selected.basis not in ANCHORS:
        raise ValueError("Select an existing relative point")
    if selected.basis == basis:
        return original
    sampled_clock = anchor_time(original, basis, today, preferences) - today * DAY
    target = today * DAY + (sampled_clock + selected.minute) % DAY
    others = tuple(point for point in stored_points(original) if point.key != key)
    before = None
    for point in others:
        middle = (target - point.minute) // DAY
        for source_day in range(middle - 1, middle + 2):
            time = point_time(original, point.key, source_day, preferences)
            if time == target:
                raise ValueError(
                    "Another point occupies the initial anchor-change minute"
                )
            if time < target and (before is None or time > before[0]):
                before = time, replace(point, source_day=source_day)
    if others:
        assert before is not None
        previous = before[1]
        index = next(i for i, point in enumerate(others) if point.key == previous.key)
        shift = previous.source_day - others[index].source_day
        ordered = tuple(
            replace(point, source_day=point.source_day + shift - 1)
            for point in others[index + 1 :]
        )
        ordered += tuple(
            replace(point, source_day=point.source_day + shift)
            for point in others[: index + 1]
        )
    else:
        ordered = ()
    group = [point for point in ordered if point.basis == basis]
    source_day = today - (sampled_clock + selected.minute) // DAY
    if group:
        previous = group[-1]
        following = replace(group[0], source_day=group[0].source_day + 1)
        if previous.source_day == following.source_day:
            if not previous.minute < selected.minute < following.minute:
                raise ValueError(
                    "The preserved offset does not fit the selected circular gap"
                )
            source_day = previous.source_day
        elif previous.source_day + 1 == following.source_day:
            if selected.minute > previous.minute:
                source_day = previous.source_day
            elif selected.minute < following.minute:
                source_day = following.source_day
            else:
                raise ValueError(
                    "The preserved offset does not fit the selected circular gap"
                )
        else:
            raise ValueError("The new anchor group has inconsistent date associations")
    changed = replace(selected, basis=basis, source_day=source_day)
    return normalize((*ordered, changed), original.anchors)


class EditorVerification(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.anchors = (Anchor(360), Anchor(1140))
        self.preferences: Preferences = lambda name, day: (
            360 if name == "Morning" else 1140
        )

    def test_normalize_split_morning_across_midnight(self) -> None:
        points = (
            Point("fixed", "Clock", 0),
            Point("after", "Morning", 240),
            Point("before", "Morning", -240, source_day=1),
        )
        schedule = normalize(points, (Anchor(60, False), Anchor(1140, False)))
        self.assertEqual(
            [row[0] for row in schedule.occurrences([0], self.preferences)],
            [1260, 1440, 1740],
        )
        self.assertEqual(schedule.anchors[0].source_day, 1)
        self.assertEqual(point_time(schedule, "before", 0, self.preferences), -180)

    def test_normalize_two_groups_across_midnight(self) -> None:
        points = (
            Point("evening-after", "Evening", 240, source_day=-1),
            Point("morning-after", "Morning", 240),
            Point("evening-before", "Evening", -240),
            Point("morning-before", "Morning", -240, source_day=1),
        )
        schedule = normalize(points, (Anchor(60, False), Anchor(1380, False)))
        self.assertEqual(
            [row[0] for row in schedule.occurrences([0], self.preferences)],
            [1140, 1260, 1620, 1740],
        )
        self.assertEqual([a.source_day for a in schedule.anchors], [1, 0])

    def test_internal_source_dates_can_differ_by_two_days(self) -> None:
        points = (
            Point("m", "Morning", 240, source_day=-1),
            Point("e", "Evening", -240, source_day=1),
        )
        schedule = normalize(points, (Anchor(1210, False), Anchor(249, False)))
        self.assertEqual(
            [row[0] for row in schedule.occurrences([0, 1], self.preferences)],
            [10, 1449, 1450, 2889],
        )
        self.assertEqual([p.minute for p in schedule.points], [240, -240])

    def test_interleaved_groups_need_not_be_contiguous(self) -> None:
        points = (
            Point("a", "Morning", -240),
            Point("b", "Evening", -240),
            Point("c", "Morning", 240),
            Point("d", "Evening", 240),
        )
        schedule = normalize(points, (Anchor(720, False), Anchor(840, False)))
        self.assertEqual(
            [row[0] for row in schedule.occurrences([0], self.preferences)],
            [480, 600, 960, 1080],
        )

    def test_reject_impossible_order_and_duplicate_identities(self) -> None:
        invalid = (
            (
                Point("a", "Morning", -240),
                Point("b", "Evening", 240),
                Point("c", "Morning", 240),
                Point("d", "Evening", -240),
            ),
            (Point("same", "Clock", 0), Point("same", "Clock", 60)),
            (Point("a", "Clock", 0), Point("b", "Clock", 0)),
            (Point("a", "Morning", 241),),
            (Point("a", "Morning", 0, source_day=0.5),),  # ty: ignore[invalid-argument-type]
        )
        for points in invalid:
            with self.subTest(points=points), self.assertRaises(ValueError):
                normalize(points, self.anchors)

    def test_source_dates_distinguish_identical_circular_identity_order(self) -> None:
        first = normalize(
            (Point("m", "Morning", 0), Point("e", "Evening", 0)), self.anchors
        )
        second = normalize(
            (Point("m", "Morning", 0), Point("e", "Evening", 0, source_day=1)),
            self.anchors,
        )

        def preferences(name: str, day: int) -> int | None:
            return 1200 if name == "Morning" else 240

        self.assertEqual(point_time(first, "e", 0, preferences), 1201)
        self.assertEqual(point_time(second, "e", 1, preferences), 1680)

    def test_static_clock_oracle_for_all_qualifying_rotations(self) -> None:
        clocks = (0, 1, 59, 60, 239, 240, 241, 420, 720, 1199, 1200, 1380, 1438, 1439)
        layouts = (
            (Point("m", "Morning", 0), Point("e", "Evening", 240)),
            (
                Point("a", "Morning", -240),
                Point("b", "Morning", 240),
                Point("c", "Evening", -240),
                Point("d", "Evening", 240),
            ),
            (
                Point("m", "Morning", -240),
                Point("f", "Clock", 0),
                Point("e", "Evening", 240),
            ),
            (
                Point("a", "Morning", -1),
                Point("b", "Morning", 1),
                Point("c", "Clock", 720),
            ),
        )
        checked = 0
        for layout, morning, evening in product(layouts, clocks, clocks):
            anchors = (Anchor(morning, False), Anchor(evening, False))
            rows = []
            for point in layout:
                clock = (
                    0
                    if point.basis == "Clock"
                    else (morning if point.basis == "Morning" else evening)
                )
                absolute = clock + point.minute
                rows.append(
                    (absolute % DAY, replace(point, source_day=-(absolute // DAY)))
                )
            if len({time for time, point in rows}) != len(rows):
                continue
            rows.sort(key=lambda row: row[0])
            raw = tuple(point for time, point in rows)
            for cut in range(len(raw)):
                rotated = raw[cut:] + tuple(
                    replace(point, source_day=point.source_day + 1)
                    for point in raw[:cut]
                )
                schedule = normalize(rotated, anchors)
                for time, point in rows:
                    self.assertEqual(
                        point_time(
                            schedule, point.key, point.source_day, self.preferences
                        ),
                        time,
                    )
                checked += 1
        self.assertGreater(checked, 2000)

    def test_rotation_modes_backups_and_restart_consistency(self) -> None:
        original = (
            Point("a", "Morning", -240),
            Point("b", "Morning", 240),
            Point("c", "Evening", -240),
            Point("d", "Evening", 240),
        )
        rotated = original[2:] + tuple(
            replace(point, source_day=1) for point in original[:2]
        )

        def preferences(name: str, day: int) -> int | None:
            return (
                None
                if day % 4 == 0
                else (day * 811 + (117 if name == "Morning" else 1303)) % DAY
            )

        for manual_morning, manual_evening in product((False, True), repeat=2):
            anchors = (
                Anchor(420, not manual_morning),
                Anchor(1140, not manual_evening),
            )
            first = normalize(original, anchors)
            second = normalize(rotated, anchors)
            for day in reversed(range(-3, 4)):
                restarted = normalize(stored_points(second), second.anchors)
                for point in original:
                    expected = point_time(first, point.key, day, preferences)
                    self.assertEqual(
                        point_time(second, point.key, day, preferences), expected
                    )
                    self.assertEqual(
                        point_time(restarted, point.key, day, preferences), expected
                    )

    def test_drag_preserves_anchor_instead_of_original_offset(self) -> None:
        selected = Point("selected", "Morning", 0, 3000)
        points = (
            selected,
            Point("fixed", "Clock", 420),
            Point("other", "Morning", 120),
            Point("late", "Clock", 600),
        )
        schedule = place(points, self.anchors, selected, 421, self.preferences)
        self.assertEqual(
            next(p.minute for p in schedule.points if p.key == "selected"), 61
        )
        self.assertEqual(anchor_time(schedule, "Morning", 0, self.preferences), 360)
        self.assertEqual(point_time(schedule, "other", 0, self.preferences), 480)
        self.assertEqual(point_time(schedule, "fixed", 0, self.preferences), 420)
        self.assertEqual(point_time(schedule, "selected", 0, self.preferences), 421)
        self.assertEqual(
            next(p.kelvin for p in schedule.points if p.key == "selected"), 3000
        )

    def test_insertion_uses_pre_edit_anchor(self) -> None:
        points = (
            Point("fixed", "Clock", 420),
            Point("other", "Morning", 120),
            Point("late", "Clock", 600),
        )
        selected = Point("new", "Morning", 0, 2500)
        schedule = place(points, self.anchors, selected, 421, self.preferences)
        self.assertEqual(next(p.minute for p in schedule.points if p.key == "new"), 61)
        self.assertEqual(point_time(schedule, "other", 0, self.preferences), 480)
        self.assertEqual(point_time(schedule, "new", 0, self.preferences), 421)

    def test_drag_reference_does_not_follow_intermediate_previews(self) -> None:
        selected = Point("selected", "Morning", 0)
        start = (
            Point("fixed", "Clock", 420),
            selected,
            Point("other", "Morning", 120),
            Point("late", "Clock", 600),
        )
        outward = place(start, self.anchors, selected, 422, self.preferences)
        self.assertEqual(
            next(p.minute for p in outward.points if p.key == "selected"), 62
        )
        returned = place(start, self.anchors, selected, 421, self.preferences)
        self.assertEqual(
            next(p.minute for p in returned.points if p.key == "selected"), 0
        )
        self.assertEqual(point_time(returned, "other", 0, self.preferences), 541)
        wrong_reference = place(
            stored_points(outward), outward.anchors, selected, 421, self.preferences
        )
        self.assertEqual(
            next(p.minute for p in wrong_reference.points if p.key == "selected"), 61
        )

    def test_searches_gaps_after_unedited_points_move(self) -> None:
        points = (
            Point("unedited", "Morning", 0),
            Point("selected", "Morning", 60),
            Point("fixed", "Clock", 500),
        )

        def preferences(name: str, day: int) -> int | None:
            return 600 if name == "Morning" else 1140

        schedule = place(points, self.anchors, points[1], 450, preferences)
        self.assertEqual(
            next(p.minute for p in schedule.points if p.key == "selected"), -49
        )
        self.assertEqual(point_time(schedule, "selected", 0, preferences), 450)
        self.assertEqual(point_time(schedule, "unedited", 0, preferences), 499)
        self.assertEqual(point_time(schedule, "fixed", 0, preferences), 500)
        occupied_before_edit = place(points, self.anchors, points[1], 439, preferences)
        self.assertEqual(
            next(p.minute for p in occupied_before_edit.points if p.key == "selected"),
            -60,
        )
        self.assertEqual(
            point_time(occupied_before_edit, "selected", 0, preferences), 439
        )
        self.assertEqual(
            point_time(occupied_before_edit, "unedited", 0, preferences), 499
        )

    def test_invalid_minute_does_not_modify_last_accepted_preview(self) -> None:
        selected = Point("selected", "Morning", 0)
        start = (selected, Point("fixed", "Clock", 420))
        last_accepted = place(start, self.anchors, selected, 419, self.preferences)
        with self.assertRaises(ValueError):
            place(start, self.anchors, selected, 420, self.preferences)
        self.assertEqual(
            point_time(last_accepted, "selected", 0, self.preferences), 419
        )
        continued = place(start, self.anchors, selected, 421, self.preferences)
        self.assertEqual(point_time(continued, "selected", 0, self.preferences), 421)
        self.assertEqual(start[0].minute, 0)

    def test_manual_relative_drag_crosses_midnight_and_fixed_point(self) -> None:
        selected = Point("selected", "Evening", 60)
        points = (
            Point("before", "Clock", 1320),
            selected,
            Point("after", "Clock", 30, source_day=1),
        )
        anchors = (Anchor(420, False), Anchor(1380, False))
        schedule = place(points, anchors, selected, 1485, self.preferences)
        self.assertEqual(
            next(p.minute for p in schedule.points if p.key == "selected"), 105
        )
        self.assertEqual(anchor_time(schedule, "Evening", 0, self.preferences), 1380)
        self.assertEqual(point_time(schedule, "before", 0, self.preferences), 1320)
        self.assertEqual(point_time(schedule, "after", 1, self.preferences), 1470)
        self.assertEqual(point_time(schedule, "selected", 0, self.preferences), 1485)

    def test_fixed_point_crossing_preserves_identity_and_temperatures(self) -> None:
        points = (
            Point("a", "Clock", 360, 2000),
            Point("b", "Clock", 480, 4000),
            Point("c", "Clock", 600, 3000),
        )
        schedule = place(points, self.anchors, points[2], 420, self.preferences)
        dated = sorted(
            (point_time(schedule, p.key, 0, self.preferences), p.key, p.kelvin)
            for p in schedule.points
        )
        self.assertEqual(dated, [(360, "a", 2000), (420, "c", 3000), (480, "b", 4000)])

    def test_fixed_point_can_move_across_midnight(self) -> None:
        points = (
            Point("a", "Clock", 1320),
            Point("selected", "Clock", 1380),
            Point("b", "Clock", 30, source_day=1),
        )
        schedule = place(points, self.anchors, points[1], 1485, self.preferences)
        self.assertEqual(point_time(schedule, "selected", 1, self.preferences), 1485)
        self.assertEqual(point_time(schedule, "b", 1, self.preferences), 1470)

    def test_equal_distance_choices_use_deterministic_offset_order(self) -> None:
        selected = Point("selected", "Evening", -118)
        points = (
            Point("a", "Morning", -240),
            Point("b", "Morning", 240),
            selected,
            Point("c", "Evening", 240),
        )

        def preferences(name: str, day: int) -> int | None:
            return (959 if day == -1 else 0) if name == "Morning" else 480

        start = normalize(points, self.anchors)
        self.assertEqual(anchor_time(start, "Evening", 0, preferences), 718)
        schedules = placement_candidates(
            points, self.anchors, selected, 719, preferences
        )
        choices = {
            (
                next(p.minute for p in s.points if p.key == "selected"),
                anchor_time(s, "Evening", 0, preferences),
            )
            for s in schedules
        }
        self.assertEqual(choices, {(-237, 956), (239, 480)})
        chosen = place(points, self.anchors, selected, 719, preferences)
        self.assertEqual(
            next(p.minute for p in chosen.points if p.key == "selected"), -237
        )
        self.assertEqual(point_time(chosen, "selected", 0, preferences), 719)

    def test_empty_curve_and_single_point_edit(self) -> None:
        selected = Point("only", "Morning", 0, 2500)
        first = place((), self.anchors, selected, 120, self.preferences)
        self.assertEqual(next(p.minute for p in first.points), -240)
        self.assertEqual(point_time(first, "only", 0, self.preferences), 120)
        last = place(
            stored_points(first), first.anchors, selected, 600, self.preferences
        )
        self.assertEqual(next(p.minute for p in last.points), 240)
        self.assertEqual(point_time(last, "only", 0, self.preferences), 600)
        with self.assertRaises(ValueError):
            place((), self.anchors, selected, 601, self.preferences)

    def test_manual_anchor_offset_limits_and_invalid_coordinates(self) -> None:
        selected = Point("only", "Evening", 0)
        anchors = (Anchor(360, False), Anchor(1380, False))
        for target, expected in ((1140, -240), (1620, 240)):
            schedule = place((selected,), anchors, selected, target, self.preferences)
            self.assertEqual(next(p.minute for p in schedule.points), expected)
        for target in (1139, 1621, 1380.5):
            with self.subTest(target=target), self.assertRaises(ValueError):
                place((selected,), anchors, selected, target, self.preferences)  # ty: ignore[invalid-argument-type]

    def test_reanchoring_normalizes_preserved_offset(self) -> None:
        anchors = (Anchor(360, False), Anchor(1140, False))
        selected = Point("selected", "Morning", 60, 2800)
        original = normalize((selected, Point("fixed", "Clock", 600)), anchors)
        moved = normalize(
            (Point("fixed", "Clock", 600), replace(selected, basis="Evening")), anchors
        )
        self.assertEqual(point_time(original, "selected", 0, self.preferences), 420)
        self.assertEqual(point_time(moved, "selected", 0, self.preferences), 1200)
        point = next(p for p in moved.points if p.key == "selected")
        self.assertEqual((point.minute, point.kelvin), (60, 2800))

    def test_current_day_occurrences_preserve_order_that_modulo_projection_loses(
        self,
    ) -> None:
        points = (
            Point("morning", "Morning", 0),
            Point("noon", "Clock", 720),
            Point("selected", "Evening", 120),
            Point("late", "Evening", 240),
        )

        def preferences(name: str, day: int) -> int | None:
            return (360 if day == 1 else 0) if name == "Morning" else 1380

        original = normalize(points, self.anchors)
        actual = [
            (time, key)
            for time, _, key in original.occurrences(range(-1, 2), preferences)
            if 0 <= time < DAY
        ]
        self.assertEqual(actual, [(0, "morning"), (720, "noon")])
        projected = sorted(
            (point_time(original, p.key, 0, preferences) % DAY, p.key)
            for p in points
            if p.key != "selected"
        )
        self.assertEqual(projected, [(0, "morning"), (180, "late"), (720, "noon")])
        candidate = normalize(
            (points[0], replace(points[2], basis="Morning"), points[1], points[3]),
            self.anchors,
        )
        self.assertEqual(point_time(candidate, "selected", 0, preferences), 120)
        self.assertEqual(
            [p.key for p in candidate.points], ["morning", "selected", "noon", "late"]
        )

    def test_reanchor_offset_order_can_move_next_days_same_anchor(self) -> None:
        def preferences(name: str, day: int) -> int | None:
            return 1380 if name == "Morning" and day == 0 else 0

        candidate = normalize(
            (Point("morning", "Morning", 0), Point("selected", "Morning", 240)),
            self.anchors,
        )
        self.assertEqual(point_time(candidate, "morning", 0, preferences), 1380)
        self.assertEqual(point_time(candidate, "selected", 0, preferences), 1620)
        self.assertEqual(point_time(candidate, "morning", 1, preferences), 1621)
        with self.assertRaises(ValueError):
            normalize(
                (
                    Point("morning", "Morning", 0, source_day=1),
                    Point("selected", "Morning", 240),
                ),
                self.anchors,
            )

    def test_current_day_reanchor_fixture_uses_selected_after_noon_order(self) -> None:
        anchors = (Anchor(1380, False), Anchor(1080))

        def preferences(name: str, day: int) -> int | None:
            return 1080 if day == 0 else 360

        selected = Point("selected", "Morning", 60, 2800)
        noon = Point("noon", "Clock", 720)
        original = normalize((noon, selected), anchors)
        self.assertEqual(point_time(original, "selected", 0, preferences), 1440)
        self.assertEqual(anchor_time(original, "Evening", 0, preferences), 1080)
        candidate = normalize((noon, replace(selected, basis="Evening")), anchors)
        self.assertEqual(point_time(candidate, "selected", 0, preferences), 1140)
        self.assertEqual(point_time(candidate, "selected", 1, preferences), 2161)
        self.assertEqual(
            next(p.kelvin for p in candidate.points if p.key == "selected"), 2800
        )

    def test_initial_reanchor_collision_permits_two_different_resolved_orders(
        self,
    ) -> None:
        anchors = (Anchor(480), Anchor(960))

        def preferences(name: str, day: int) -> int | None:
            return 480 if name == "Morning" else 960

        selected = Point("selected", "Morning", -240, 2800)
        other = Point("other", "Morning", 240)
        fixed = Point("fixed", "Clock", 1080)
        original = normalize((selected, other, fixed), anchors)
        self.assertEqual(point_time(original, "selected", 0, preferences), 240)
        self.assertEqual(point_time(original, "other", 0, preferences), 720)
        self.assertEqual(
            anchor_time(original, "Evening", 0, preferences) + selected.minute, 720
        )
        changed = replace(selected, basis="Evening")
        for order, expected in (
            ((changed, other, fixed), 719),
            ((other, changed, fixed), 721),
        ):
            with self.subTest(expected=expected):
                candidate = normalize(order, anchors)
                self.assertEqual(
                    point_time(candidate, "selected", 0, preferences), expected
                )
                self.assertEqual(point_time(candidate, "other", 0, preferences), 720)
                self.assertEqual(point_time(candidate, "fixed", 0, preferences), 1080)
                self.assertEqual(
                    next(p.minute for p in candidate.points if p.key == "selected"),
                    -240,
                )
        with self.assertRaises(ValueError):
            normalize((replace(selected, minute=240), other, fixed), anchors)

    def test_reanchor_rejects_initial_collision_before_automatic_resolution(
        self,
    ) -> None:
        anchors = (Anchor(480), Anchor(960))

        def preferences(name: str, day: int) -> int | None:
            return 480 if name == "Morning" else 960

        selected = Point("selected", "Morning", -240, 2800)
        points = (
            selected,
            Point("other", "Morning", 240),
            Point("fixed", "Clock", 1080),
        )
        with self.assertRaisesRegex(ValueError, "occupies the initial"):
            reanchor(points, anchors, "selected", "Evening", 0, preferences)
        self.assertEqual(points[0], Point("selected", "Morning", -240, 2800))
        self.assertEqual(
            point_time(normalize(points, anchors), "selected", 0, preferences), 240
        )
        adjusted = (replace(selected, minute=-239), *points[1:])
        accepted = reanchor(adjusted, anchors, "selected", "Evening", 0, preferences)
        self.assertEqual(point_time(accepted, "selected", 0, preferences), 721)

    def test_reanchor_uses_actual_current_day_neighbors(self) -> None:
        points = (
            Point("morning", "Morning", 0),
            Point("noon", "Clock", 720),
            Point("selected", "Evening", 120, 2800),
            Point("late", "Evening", 240),
        )

        def preferences(name: str, day: int) -> int | None:
            return (360 if day == 1 else 0) if name == "Morning" else 1380

        changed = reanchor(points, self.anchors, "selected", "Morning", 0, preferences)
        self.assertEqual(point_time(changed, "selected", 0, preferences), 120)
        self.assertEqual(point_time(changed, "morning", 0, preferences), 0)
        self.assertEqual(point_time(changed, "noon", 0, preferences), 720)
        self.assertEqual(point_time(changed, "late", 0, preferences), 1620)
        selected = next(p for p in changed.points if p.key == "selected")
        self.assertEqual(
            (selected.basis, selected.minute, selected.kelvin), ("Morning", 120, 2800)
        )

    def test_reanchor_joins_existing_group_across_midnight(self) -> None:
        points = (Point("morning", "Morning", 0), Point("selected", "Evening", 240))

        def preferences(name: str, day: int) -> int | None:
            return 1380 if name == "Morning" and day == 0 else 0

        changed = reanchor(points, self.anchors, "selected", "Morning", 0, preferences)
        self.assertEqual(point_time(changed, "morning", 0, preferences), 1380)
        self.assertEqual(point_time(changed, "selected", 0, preferences), 1620)
        self.assertEqual(point_time(changed, "morning", 1, preferences), 1621)

    def test_reanchor_with_two_groups_crossing_midnight(self) -> None:
        anchors = (Anchor(60, False), Anchor(1380, False))
        points = (
            Point("evening-before", "Evening", -240),
            Point("morning-before", "Morning", -240, source_day=1),
            Point("selected", "Evening", -60),
            Point("evening-after", "Evening", 240),
            Point("morning-after", "Morning", 240, source_day=1),
        )
        changed = reanchor(points, anchors, "selected", "Morning", 0, self.preferences)
        self.assertEqual(point_time(changed, "selected", 0, self.preferences), 0)
        self.assertEqual(
            point_time(changed, "morning-before", 0, self.preferences), -180
        )
        self.assertEqual(
            point_time(changed, "evening-after", -1, self.preferences), 180
        )
        self.assertEqual(point_time(changed, "morning-after", 0, self.preferences), 300)

    def test_reanchor_uses_today_when_new_anchor_has_no_other_points(self) -> None:
        anchors = (Anchor(1380, False), Anchor(1080))
        points = (Point("noon", "Clock", 720), Point("selected", "Morning", 60, 2800))

        def preferences(name: str, day: int) -> int | None:
            return 1080 if day == 0 else 360

        changed = reanchor(points, anchors, "selected", "Evening", 0, preferences)
        self.assertEqual(point_time(changed, "selected", 0, preferences), 1140)
        self.assertEqual(point_time(changed, "selected", 1, preferences), 2161)
        tomorrow = reanchor(points, anchors, "selected", "Evening", 1, preferences)
        self.assertEqual(point_time(tomorrow, "selected", 0, preferences), 719)
        self.assertEqual(point_time(tomorrow, "selected", 1, preferences), 1860)

    def test_reanchor_rejects_fixed_collision_and_invalid_selection(self) -> None:
        points = (Point("selected", "Morning", 60), Point("fixed", "Clock", 1200))
        with self.assertRaisesRegex(ValueError, "occupies the initial"):
            reanchor(points, self.anchors, "selected", "Evening", 0, self.preferences)
        for key, basis, day in (
            ("missing", "Evening", 0),
            ("fixed", "Morning", 0),
            ("selected", "Clock", 0),
            ("selected", "Evening", 0.5),
        ):
            with (
                self.subTest(key=key, basis=basis, day=day),
                self.assertRaises(ValueError),
            ):
                reanchor(points, self.anchors, key, basis, day, self.preferences)  # ty: ignore[invalid-argument-type]

    def test_reanchor_matches_independent_manual_clock_order(self) -> None:
        clocks = (0, 60, 360, 720, 1380, 1439)
        for morning, evening, offset, basis, with_group in product(
            clocks, clocks, (-240, -1, 0, 1, 240), ANCHORS, (False, True)
        ):
            anchors = (Anchor(morning, False), Anchor(evening, False))
            old_basis = ANCHORS[1 - ANCHORS.index(basis)]
            selected = Point("selected", old_basis, offset, 2800)
            definitions = [
                selected,
                Point("noon", "Clock", 720),
                Point("late", "Clock", 1200),
            ]
            if with_group:
                definitions.append(Point("group", basis, 0, 4500))
            times = {}
            dated = []
            for point in definitions:
                time = (
                    point.minute
                    if point.basis == "Clock"
                    else anchors[ANCHORS.index(point.basis)].clock + point.minute
                )
                times[point.key] = time % DAY
                dated.append(replace(point, source_day=-(time // DAY)))
            if len(set(times.values())) != len(times):
                continue
            dated.sort(key=lambda point: times[point.key])
            target = (anchors[ANCHORS.index(basis)].clock + offset) % DAY
            with self.subTest(
                morning=morning,
                evening=evening,
                offset=offset,
                basis=basis,
                with_group=with_group,
            ):
                if target in (
                    value for key, value in times.items() if key != "selected"
                ):
                    with self.assertRaises(ValueError):
                        reanchor(dated, anchors, "selected", basis, 0, self.preferences)
                    continue
                changed = reanchor(
                    dated, anchors, "selected", basis, 0, self.preferences
                )
                expected = sorted(
                    (
                        target if point.key == "selected" else times[point.key],
                        point.kelvin,
                        point.key,
                    )
                    for point in definitions
                )
                actual = [
                    row
                    for row in changed.occurrences(range(-2, 3), self.preferences)
                    if 0 <= row[0] < DAY
                ]
                self.assertEqual(actual, expected)

    def test_reanchor_single_point_keeps_offset_and_temperature(self) -> None:
        points = (Point("selected", "Morning", -240, 2800),)
        changed = reanchor(
            points, self.anchors, "selected", "Evening", 7, self.preferences
        )
        self.assertEqual(point_time(changed, "selected", 7, self.preferences), 10980)
        point = next(iter(changed.points))
        self.assertEqual(
            (point.basis, point.minute, point.kelvin), ("Evening", -240, 2800)
        )

    def test_reanchor_unused_group_phase_is_rotation_and_date_independent(self) -> None:
        cases = (
            (360, -120, 60, False, 60, -60, 1380),
            (360, 240, 1380, False, 1380, 1620, 3060),
            (1380, 60, 1080, True, 360, 1140, 2161),
            (360, -120, 60, True, 1080, -60, 2159),
        )
        for (
            morning,
            offset,
            evening,
            automatic,
            next_evening,
            expected_today,
            expected_next,
        ) in cases:
            for today in (-5, 0, 7):
                anchors = (Anchor(morning, False), Anchor(evening, automatic))

                def preferences(
                    name: str,
                    day: int,
                    evening: int = evening,
                    today: int = today,
                    next_evening: int = next_evening,
                ) -> int:
                    return evening if day == today else next_evening

                selected = Point("selected", "Morning", offset)
                noon = Point("noon", "Clock", 720)
                original = (
                    (selected, noon) if morning + offset < 720 else (noon, selected)
                )
                rotated = (*original[1:], replace(original[0], source_day=1))
                for order in (original, rotated):
                    with self.subTest(
                        case=(morning, offset, evening, automatic),
                        today=today,
                        order=order,
                    ):
                        changed = reanchor(
                            order, anchors, "selected", "Evening", today, preferences
                        )
                        self.assertEqual(
                            point_time(changed, "selected", today, preferences),
                            today * DAY + expected_today,
                        )
                        self.assertEqual(
                            point_time(changed, "selected", today + 1, preferences),
                            today * DAY + expected_next,
                        )
                        self.assertEqual(
                            point_time(changed, "noon", today, preferences),
                            today * DAY + 720,
                        )

    def test_reanchor_preserves_changing_unedited_group_order(self) -> None:
        points = (Point("morning", "Morning", 0), Point("selected", "Morning", 240))

        def preferences(name: str, day: int) -> int | None:
            return (1380 if name == "Morning" else 60) if day == 0 else 0

        original = normalize(points, self.anchors)
        self.assertEqual(point_time(original, "morning", 1, preferences), 1621)
        changed = reanchor(points, self.anchors, "selected", "Evening", 0, preferences)
        self.assertEqual(point_time(changed, "selected", 0, preferences), 300)
        self.assertEqual(point_time(changed, "selected", 1, preferences), 1680)
        self.assertEqual(point_time(changed, "morning", 0, preferences), 1380)
        self.assertEqual(point_time(changed, "morning", 1, preferences), 1681)

    def test_reanchor_rejects_duplicate_group_offset_without_initial_collision(
        self,
    ) -> None:
        points = (Point("other", "Morning", 240), Point("selected", "Evening", 240))

        def preferences(name: str, day: int) -> int | None:
            return 1380 if name == "Morning" and day == 0 else 0

        with self.assertRaisesRegex(ValueError, "preserved offset"):
            reanchor(points, self.anchors, "selected", "Morning", 0, preferences)

    def test_unchanged_time_preserves_order_and_accepts_temperature_edit(self) -> None:
        selected = Point("selected", "Morning", 0, 2800)
        points = (
            Point("fixed", "Clock", 420),
            selected,
            Point("other", "Morning", 120),
            Point("late", "Clock", 600),
        )
        original = normalize(points, self.anchors)
        actual = place(
            points, self.anchors, replace(selected, kelvin=3000), 421, self.preferences
        )
        expected = tuple(
            replace(p, kelvin=3000) if p.key == "selected" else p
            for p in original.points
        )
        self.assertEqual(actual.points, expected)
        self.assertEqual(actual.anchors, original.anchors)


if __name__ == "__main__":
    unittest.main(verbosity=2)
