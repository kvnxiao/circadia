# Daily schedule resolution probe

This probe checks whether a daily Night Light temperature curve can preserve fixed clock points and point order while automatic Morning and Evening anchors follow preferred times from solar events or backup clocks. It tests a bounded resolver, a separately implemented comparison solver over a bounded date range, synthetic daylight-saving transitions, graph-edit calculations with supplied date associations, and conversion through installed Windows time-zone rules.

**Verified on 2026-10-16:** All 23 resolver tests, 36 editor tests, and 10 Windows clock tests pass with CPython 3.15.0a2 on Windows x64. The candidate preserves one-minute spacing across neighboring dates, uses adjustable backup times when solar events are missing, and returns the same occurrences after a restart or a change in evaluation order. The [resolver research](../../docs/research/schedule-resolution.md) explains the feasibility argument and finite dependency bound. The [editor research](../../docs/research/schedule-editor-resolution.md) records cycle conversion, insertion, drag selection, and current-day anchor changes. The [Windows clock research](../../docs/research/windows-clock-conversion.md) records skipped/repeated times, half-hour changes, and conversion limits.

The automatic/fixed-point model is post-MVP research. Circadia's current [schedule](../../docs/specs/schedule.md) uses manual Wake/Bedtime clocks and relative-only points. Manual arithmetic and Windows clock fixtures remain useful references; the automatic resolver and placement search are not MVP implementation requirements.

## Run

From the repository root in MSYS2 Bash, run the shared checks and non-mutating test suites:

```bash
just --justfile probes/justfile python-check
just --justfile probes/justfile python-test
```

The [Python validation guide](../README.md#python-validation) records tool versions, rule coverage, and formatting commands. On 2026-10-16, Ruff 0.17.1 lint and formatting checks and ty 0.0.89 checks pass for all six scripts. The test recipe runs the resolver, editor, ordered-placement, and Windows clock suites through `uv run --no-project --python 3.15 python -B`. Their 23, 36, 38, and 10 tests pass respectively.

The verified Python 3.15 interpreter is 3.15.0a2, the version selected by `uv` in this environment. The Python scripts use only Python's standard library. They have no third-party Python dependencies or separate package lockfile. The static-analysis tools run in `uvx` environments. `uv` needs access to its cache and can download the requested Python version if it is absent. The resolver and editor scripts do not access the network, registry, display, or Windows APIs. The clock script requires Windows and reads installed time-zone rules through Windows APIs; it does not change settings or Night Light. None of the scripts creates configuration or result files; `-B` prevents Python bytecode files.

To reproduce the separate API limitation observations, run:

```bash
uv run --no-project --python 3.15 python -B probes/schedule-resolution/windows_clock.py --diagnostics
```

This command prints results from Windows conversions that select rules through a named dynamic time-zone structure, alongside conversions supplied explicit rules for one local year. It does not assert that the observed limitations must persist after Windows updates. It changes only in-memory copies of time-zone structures.

Keep these commands separate from application checks. They run reference calculations, not the application scheduler.

## Inputs and coverage

The resolver script takes an already normalized cyclic sequence: each saved point appears once, and the cycle boundary does not split points attached to the same anchor occurrence. Morning and Evening can each be manual or automatic. Relative offsets range from -240 through 240 whole minutes; fixed clock points retain their times. The cycle index identifies a reference date. Source-date shifts are whole-day offsets from that date, associating each anchor group with its calendar date. These shifts describe relative cycle positions in the fixtures. They do not assign an absolute calendar date or a user-configurable multi-day offset to a recurring point.

Coverage includes:

- Exact and impossible placements, duplicate times, offset bounds, and all four manual/automatic combinations.
- Cross-midnight constraints, solar-to-backup changes, cycle rotation, and restart consistency.
- Comparison with a finite solver on four layouts and twelve seeded preference sequences per layout, plus a small brute-force comparison.
- Synthetic skipped and repeated clock times, elapsed-time interpolation, dense curves, and constant curves.

The candidate gives Morning priority over Evening and earlier dated anchor occurrences priority when choosing feasible times within each anchor type. Constraints between occurrences of the same anchor need at most four neighboring cycles to propagate. This bound follows from the two-anchor model and four-hour offset limit. Nested Morning/Evening calculations can consult more than four neighboring dates.

The editor script converts a supplied dated cycle into that representation. It searches candidate placements using the resulting curve and minimizes the selected anchor's movement from its pre-edit position. Its coverage includes:

- More than 2,000 cycle-rotation checks against direct manual-clock expectations, including midnight crossings and interleaved anchor groups.
- All manual/automatic combinations, changing preferences, backup use, and reconstruction of equivalent cycles.
- Insertion, point crossing, moving neighbors, invalid placements, offset boundaries, and the original anchor reference while dragging away and back.
- Equal-distance selection, fixed and relative points crossing midnight, and complete anchor-change calculations from a supplied current local date. These derive the new recurring relationships, reject initial collisions, and cover unused anchor groups, equivalent rotations, and an automatic anchor moving the next date to preserve spacing.

The Windows clock script uses named installed zones and explicit local-year rules. It verifies skipped and repeated times, four dense transition days, half-hour changes, offsets before conversion, elapsed-time interpolation, and year-boundary fixtures. It fails on non-Windows hosts instead of reporting a successful skipped run. It does not change the host zone or daylight-adjustment setting.

## Remaining gaps

The editor probe receives stored point identities and date associations. Anchor changes receive a supplied current local date. It does not verify native hit-testing, insertion's choice of anchor date, Windows date sampling, selection persistence, or integration with numeric fields and Save. Its exhaustive search does not establish production responsiveness. The combined harness now covers real solar events, native clock conversion, and actual host time-setting changes. Native graph/controller integration, fades, UI behavior, and deployment remain outside this probe. The Windows clock research records the limits of its tested conversion cases.

Changes to anchor count, offset limits, source-date assignment, ordering, priority, or clock-change policy require rechecking the model and its bound. Production code needs validation against the [schedule requirements](../../docs/specs/schedule.md), including the editor and Windows integration cases that this probe omits.

See the [probe index](../README.md) for the other independently runnable experiments.

## Combined calculation and host settings

Build `solar-events` and run the integration suite from the repository root:

```bash
just --justfile probes/justfile python-integration
```

Eight tests passed on the same recorded host. This harness invokes the Rust solar binary, reads Windows time-zone rules, and runs the resolver. It checks midnight rounding, repeated sunsets, polar backups, manual/automatic/fixed combinations, elapsed interpolation, restart consistency, and selected clock boundaries. It does not change host settings or Night Light. The [integration report](../../docs/research/schedule-integration.md) records the results and historical conversion limit.

The separate command below temporarily changes the host time zone and daylight-adjustment setting, then restores the captured zone in `finally`. It does not change the UTC clock. Run it only as an explicit desktop verification step; other running applications can observe the temporary local-time changes. Forced termination can prevent restoration.

```bash
uv run --no-project --python 3.15 python -B probes/schedule-resolution/host_settings.py --exercise
```

The live exercise passed for UTC and Eastern time with daylight adjustment disabled and enabled, then restored Eastern time with daylight adjustment enabled.

## Ordered placement search

The separate `placement.py` variant ranks candidate offsets before testing placements between neighboring points on specific dates and stops at the first valid winner. It preserves the exhaustive reference's ranking for a fixed supplied anchor date and valid deterministic preference snapshots. It passes all 36 editor cases with the replacement search plus two direct equivalence tests. This variant does not choose insertion's internal anchor occurrence across dates or verify the time range displayed by the native graph. Its timings apply to the automatic-anchor model, not to the simpler manual Wake/Bedtime editor.

```bash
uv run --no-project --python 3.15 python -B probes/schedule-resolution/placement.py
uv run --no-project --python 3.15 python -B probes/schedule-resolution/placement.py --benchmark
```

The benchmark prints three-sample median timings for mixed and all-relative curves of 3, 10, and 30 points. It does not change Windows settings or access the network. See the [editor timing report](../../docs/research/schedule-editor-resolution.md#reference-search-timing) for measured results and limits.
