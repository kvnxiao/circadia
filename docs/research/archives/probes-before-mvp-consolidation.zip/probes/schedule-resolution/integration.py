import ctypes as c
import json
import subprocess
import sys
import unittest
from collections.abc import Iterable, Mapping, Sequence
from ctypes import wintypes as w
from datetime import datetime, timedelta
from fractions import Fraction
from functools import cache
from math import floor
from pathlib import Path
from typing import TypedDict, cast

from verify import Anchor, Occurrence, Point, Preferences, Schedule, temperature
from windows_clock import DynamicTimeZone, SystemTime, TimeZone, WindowsClock

EPOCH = datetime(1970, 1, 1)
MINUTE = timedelta(minutes=1)


class SolarEvents(TypedDict):
    rises: list[float]
    sets: list[float]


class NativeDates:
    def __init__(self, name: str | None = None, disabled: bool = False) -> None:
        self.clock = WindowsClock()
        if name is None:
            function = self.clock.kernel.GetDynamicTimeZoneInformation
            function.argtypes = [c.POINTER(DynamicTimeZone)]
            function.restype = w.DWORD
            zone = DynamicTimeZone()
            if function(c.byref(zone)) == 0xFFFFFFFF:
                raise c.WinError(c.get_last_error())
            name, disabled = zone.key, bool(zone.disabled)
        self.name, self.disabled = name, disabled

    @cache  # noqa: B019 - Cached native snapshots last for this probe process.
    def rules(self, year: int) -> TimeZone:
        result = self.clock.rules(self.name, year)
        if self.disabled:
            result.bias += result.standard_bias
            result.standard_bias = 0
            result.standard_date = SystemTime()
            result.daylight_date = SystemTime()
        return result

    def local(self, utc: datetime, year: int | None = None) -> datetime:
        if year is not None:
            return self.clock.local_time(utc, self.rules(year))
        matches = {
            self.clock.local_time(utc, self.rules(year))
            for year in (utc.year - 1, utc.year, utc.year + 1)
        }
        matches = {
            local
            for local in matches
            if self.clock.local_time(utc, self.rules(local.year)) == local
        }
        if len(matches) != 1:
            raise ValueError(f"ambiguous local-year conversion: {utc}, {matches}")
        return matches.pop()

    def occurrence(self, local: datetime) -> datetime | None:
        candidates = self.clock.candidates(local, self.rules(local.year))
        return candidates[0] if candidates else None

    def boundary(self, date: datetime) -> datetime:
        for minute in range(2880):
            instant = self.occurrence(date + minute * MINUTE)
            if instant is not None:
                return instant
        raise ValueError("No valid date boundary within two days")

    def rounded_candidates(self, stamps: Iterable[float], date: datetime) -> list[int]:
        result = set()
        for stamp in stamps:
            local = self.local(EPOCH + floor((stamp + 30) / 60) * MINUTE, date.year)
            if local.date() == date.date():
                result.add(local.hour * 60 + local.minute)
        return sorted(result)


def choose(candidates: Sequence[int], backup: int) -> int | None:
    return (
        min(candidates, key=lambda minute: (abs(minute - backup), minute))
        if candidates
        else None
    )


class SolarPreferences:
    def __init__(
        self,
        native: NativeDates,
        origin: datetime,
        latitude: float,
        longitude: float,
        dates: Iterable[int],
    ) -> None:
        self.native, self.origin = native, origin
        dates = list(dates)
        requests = []
        for day in dates:
            date = origin + timedelta(days=day)
            start = native.boundary(date)
            end = native.boundary(date + timedelta(days=1))
            requests.append(
                dict(
                    year=date.year,
                    month=date.month,
                    latitude=latitude,
                    longitude=longitude,
                    start=(start - EPOCH).total_seconds() - 30,
                    end=(end - EPOCH).total_seconds() + 30,
                )
            )
        binary = (
            Path(__file__).resolve().parents[1]
            / "solar-calculation/target/debug/solar-events.exe"
        )
        run = subprocess.run(
            [binary],
            input=json.dumps(requests),
            text=True,
            capture_output=True,
            check=True,
        )
        events = cast(list[SolarEvents], json.loads(run.stdout))
        if len(events) != len(dates):
            raise ValueError("Solar response length mismatch")
        self.events: dict[int, dict[str, list[int]]] = {}
        for day, event in zip(dates, events, strict=True):
            date = origin + timedelta(days=day)
            self.events[day] = {
                "Morning": native.rounded_candidates(event["rises"], date),
                "Evening": native.rounded_candidates(event["sets"], date),
            }

    def callback(self, backups: Mapping[str, int]) -> Preferences:
        return lambda name, day: choose(self.events[day][name], backups[name])


def actual(
    schedule: Schedule,
    days: Iterable[int],
    preferences: Preferences,
    native: NativeDates,
    origin: datetime,
) -> list[Occurrence]:
    result = []
    for minute, kelvin, key in schedule.occurrences(days, preferences):
        instant = native.occurrence(origin + minute * MINUTE)
        if instant is not None:
            result.append(((instant - EPOCH) // MINUTE, kelvin, key))
    return sorted(result)


class IntegrationTests(unittest.TestCase):
    def test_native_date_lengths(self) -> None:
        cases = [
            ("Eastern Standard Time", "2026-03-08", 23),
            ("Eastern Standard Time", "2026-11-01", 25),
            ("Lord Howe Standard Time", "2026-10-04", 23.5),
            ("Lord Howe Standard Time", "2026-04-05", 24.5),
        ]
        for zone, date, hours in cases:
            with self.subTest(zone=zone, date=date):
                native = NativeDates(zone)
                start = datetime.fromisoformat(date)
                self.assertEqual(
                    native.boundary(start + timedelta(days=1)) - native.boundary(start),
                    timedelta(hours=hours),
                )

    def test_round_before_local_date_assignment(self) -> None:
        native = NativeDates("Eastern Standard Time")
        day = datetime(2026, 7, 1)
        stamps = [(datetime(2026, 7, 2, 3, 59, 40) - EPOCH).total_seconds()]
        self.assertEqual(native.rounded_candidates(stamps, day), [])
        self.assertEqual(
            native.rounded_candidates(stamps, day + timedelta(days=1)), [0]
        )
        self.assertEqual(
            native.rounded_candidates(
                [(datetime(2026, 7, 1, 4, 0, 30) - EPOCH).total_seconds()], day
            ),
            [1],
        )

    def test_repeated_hour_rounding_uses_utc_instant(self) -> None:
        native = NativeDates("Eastern Standard Time")
        stamp = (datetime(2026, 11, 1, 5, 59, 40) - EPOCH).total_seconds()
        self.assertEqual(
            native.rounded_candidates([stamp], datetime(2026, 11, 1)), [60]
        )

    def test_repeated_solar_events_and_backup_distance(self) -> None:
        solar = SolarPreferences(
            NativeDates("W. Europe Standard Time"),
            datetime(2026, 7, 27),
            69.6492,
            18.9553,
            [0],
        )
        self.assertEqual(solar.events[0]["Evening"], [13, 1439])
        self.assertEqual(solar.callback({"Evening": 1140})("Evening", 0), 1439)
        self.assertEqual(solar.callback({"Evening": 0})("Evening", 0), 13)
        self.assertEqual(choose([10, 30], 20), 10)

    def test_polar_missing_events_use_manual_backup(self) -> None:
        solar = SolarPreferences(
            NativeDates("W. Europe Standard Time"),
            datetime(2026, 6, 21),
            69.6492,
            18.9553,
            range(-15, 16),
        )
        self.assertEqual(solar.events[0], {"Morning": [], "Evening": []})
        schedule = Schedule(
            [Point("m", "Morning", 0), Point("e", "Evening", 0)],
            [Anchor(420), Anchor(1140)],
        )
        self.assertEqual(
            schedule.resolve(0, solar.callback({"Morning": 420, "Evening": 1140})),
            (420, 1140),
        )

    def test_real_solar_resolver_and_elapsed_interpolation(self) -> None:
        origin = datetime(2026, 3, 8)
        native = NativeDates("Eastern Standard Time")
        solar = SolarPreferences(native, origin, 40.7128, -74.0060, range(-20, 21))
        schedule = Schedule(
            [
                Point("m", "Morning", 0, 6500),
                Point("e", "Evening", 0, 3000),
                Point("bed", "Clock", 1380, 1800),
            ],
            [Anchor(420, False), Anchor(1140)],
        )
        preferences = solar.callback({"Morning": 420, "Evening": 1140})
        evening = preferences("Evening", 0)
        assert evening is not None
        self.assertTrue(1100 <= evening <= 1160)
        points = actual(schedule, range(-2, 3), preferences, native, origin)
        by_key = {
            key: minute
            for minute, _, key in points
            if native.local(EPOCH + minute * MINUTE).date() == origin.date()
        }
        self.assertEqual(EPOCH + by_key["m"] * MINUTE, datetime(2026, 3, 8, 11))
        self.assertEqual(EPOCH + by_key["bed"] * MINUTE, datetime(2026, 3, 9, 3))
        values = [(minute, kelvin) for minute, kelvin, _ in points]
        self.assertEqual(temperature(values, by_key["bed"]), 1800)
        midpoint = Fraction(by_key["m"] + by_key["e"], 2)
        self.assertEqual(temperature(values, midpoint), 4750)
        self.assertEqual(
            points,
            actual(
                Schedule(schedule.points, schedule.anchors),
                range(-2, 3),
                preferences,
                native,
                origin,
            ),
        )
        self.assertEqual(
            points,
            actual(schedule, reversed(range(-2, 3)), preferences, native, origin),
        )

    def test_missing_and_repeated_schedule_points(self) -> None:
        native = NativeDates("Eastern Standard Time")
        schedule = Schedule(
            [
                Point("a", "Clock", 90, 6000),
                Point("b", "Clock", 150, 2000),
                Point("c", "Clock", 210, 3000),
            ],
            [Anchor(420), Anchor(1140)],
        )

        def preferences(name: str, day: int) -> int | None:
            return None

        points = actual(schedule, [0], preferences, native, datetime(2026, 3, 8))
        self.assertEqual(
            [(EPOCH + minute * MINUTE, k, key) for minute, k, key in points],
            [
                (datetime(2026, 3, 8, 6, 30), 6000, "a"),
                (datetime(2026, 3, 8, 7, 30), 3000, "c"),
            ],
        )
        self.assertEqual(
            temperature(
                [(m, k) for m, k, _ in points],
                (datetime(2026, 3, 8, 7) - EPOCH) // MINUTE,
            ),
            4500,
        )
        fall = actual(schedule, [0], preferences, native, datetime(2026, 11, 1))
        self.assertEqual(EPOCH + fall[0][0] * MINUTE, datetime(2026, 11, 1, 5, 30))

    def test_year_boundary_and_disabled_daylight(self) -> None:
        self.assertEqual(
            NativeDates("Samoa Standard Time").local(
                datetime(2011, 12, 31, 10, 30), 2012
            ),
            datetime(2012, 1, 1, 0, 30),
        )
        self.assertEqual(
            NativeDates("Eastern Standard Time", True).local(datetime(2026, 7, 1, 17)),
            datetime(2026, 7, 1, 12),
        )


if __name__ == "__main__":
    if sys.platform != "win32":
        raise SystemExit("This probe requires Windows time-zone APIs")
    unittest.main()
