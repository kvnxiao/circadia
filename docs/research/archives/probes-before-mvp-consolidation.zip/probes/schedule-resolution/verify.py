import random
import unittest
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from fractions import Fraction
from functools import cache
from itertools import pairwise, product
from typing import override

type Preferences = Callable[[str, int], int | None]
type Occurrence = tuple[int, int, str]

DAY = 24 * 60
OFFSET_LIMIT = 4 * 60
ANCHORS = ("Morning", "Evening")
MAX_EDGE_WEIGHT = 2 * OFFSET_LIMIT + 1
HISTORY = (MAX_EDGE_WEIGHT + DAY - 1) // (DAY - 2 * MAX_EDGE_WEIGHT)


@dataclass(frozen=True)
class Anchor:
    clock: int
    automatic: bool = True
    source_day: int = 0


@dataclass(frozen=True)
class Point:
    key: str
    basis: str
    minute: int
    kelvin: int = 4000
    source_day: int = 0


@dataclass(frozen=True)
class Edge:
    source: int
    target: int
    advance: int
    weight: int


def longest_paths(
    count: int, edges: Iterable[tuple[int, int, int]]
) -> list[list[int | None]]:
    distance: list[list[int | None]] = [[None] * count for _ in range(count)]
    for node in range(count):
        distance[node][node] = 0
    for source, target, weight in edges:
        old = distance[source][target]
        distance[source][target] = weight if old is None else max(old, weight)
    for middle in range(count):
        for source in range(count):
            left = distance[source][middle]
            if left is None:
                continue
            for target in range(count):
                right = distance[middle][target]
                if right is None:
                    continue
                candidate = left + right
                old = distance[source][target]
                if old is None or candidate > old:
                    distance[source][target] = candidate
    for node, row in enumerate(distance):
        diagonal = row[node]
        if diagonal is not None and diagonal > 0:
            raise ValueError("The point order has no feasible placement")
    return distance


def path_weights(anchor: int, edges: Sequence[Edge]) -> tuple[int | None, ...]:
    links = []
    for day in range(HISTORY + 1):
        for edge in edges:
            later = day + edge.advance
            if later <= HISTORY:
                links.append(
                    (2 * day + edge.source, 2 * later + edge.target, edge.weight)
                )
    distance = longest_paths(2 * (HISTORY + 1), links)
    return tuple(distance[anchor][2 * day + anchor] for day in range(HISTORY + 1))


def clamp(value: int, lower: int, upper: int) -> int:
    if lower > upper:
        raise ValueError("The anchor interval is empty")
    return max(lower, min(value, upper))


class Schedule:
    def __init__(self, points: Sequence[Point], anchors: Sequence[Anchor]) -> None:
        self.points = tuple(points)
        self.anchors = tuple(anchors)
        if not points or len(anchors) != 2:
            raise ValueError("A cycle needs points and two anchors")
        if len({point.key for point in points}) != len(points):
            raise ValueError("Point identities must be unique")
        for anchor in anchors:
            if type(anchor.clock) is not int or not 0 <= anchor.clock < DAY:
                raise ValueError("An anchor clock must be a whole minute within a day")
            if type(anchor.source_day) is not int:
                raise ValueError("A source date shift must be an integer")
        for point in points:
            if type(point.minute) is not int or type(point.source_day) is not int:
                raise ValueError("Point positions must use whole minutes and dates")
            if point.basis == "Clock":
                if not 0 <= point.minute < DAY:
                    raise ValueError("A fixed clock time must be within a day")
            elif point.basis in ANCHORS:
                if abs(point.minute) > OFFSET_LIMIT or point.source_day != 0:
                    raise ValueError(
                        "Relative points must use their anchor and an offset within four hours"
                    )
            else:
                raise ValueError("Unknown point basis")
            if (
                type(point.kelvin) is not int
                or not 1200 <= point.kelvin <= 6500
                or point.kelvin % 10
            ):
                raise ValueError("Point temperatures must use supported 10 K steps")
        lower = []
        upper = []
        for anchor in anchors:
            origin = anchor.source_day * DAY
            lower.append(origin if anchor.automatic else origin + anchor.clock)
            upper.append(
                origin + DAY - 1 if anchor.automatic else origin + anchor.clock
            )
        edges = []
        for index, before in enumerate(points):
            after = points[(index + 1) % len(points)]
            advance = int(index + 1 == len(points))
            first = before.minute + before.source_day * DAY
            second = after.minute + after.source_day * DAY
            weight = first - second + 1 - advance * DAY
            if before.basis == "Clock" and after.basis == "Clock":
                if weight > 0:
                    raise ValueError("Fixed points conflict with the saved order")
            elif before.basis == "Clock":
                target = ANCHORS.index(after.basis)
                lower[target] = max(lower[target], weight)
            elif after.basis == "Clock":
                source = ANCHORS.index(before.basis)
                upper[source] = min(upper[source], -weight)
            else:
                edges.append(
                    Edge(
                        ANCHORS.index(before.basis),
                        ANCHORS.index(after.basis),
                        advance,
                        weight,
                    )
                )
        self.edges = tuple(edges)
        links = [(edge.source, edge.target, edge.weight) for edge in edges]
        for anchor in range(2):
            links.extend(((2, anchor, lower[anchor]), (anchor, 2, -upper[anchor])))
        distance = longest_paths(3, links)
        lower_bounds = []
        upper_bounds = []
        for anchor in range(2):
            low, high = distance[2][anchor], distance[anchor][2]
            assert low is not None and high is not None
            lower_bounds.append(low)
            upper_bounds.append(-high)
        self.lower = tuple(lower_bounds)
        self.upper = tuple(upper_bounds)
        self.morning_weights = path_weights(0, edges)
        self.evening_weights = path_weights(
            1, [edge for edge in edges if edge.source == edge.target == 1]
        )

    def resolve(self, day: int, preferences: Preferences) -> tuple[int, int]:
        def preferred(anchor_index: int, cycle: int) -> int:
            anchor = self.anchors[anchor_index]
            value = (
                preferences(ANCHORS[anchor_index], cycle + anchor.source_day)
                if anchor.automatic
                else None
            )
            if value is None:
                value = anchor.clock
            if type(value) is not int or not 0 <= value < DAY:
                raise ValueError(
                    "A preferred clock time must be a whole minute within a day"
                )
            return value + anchor.source_day * DAY

        @cache
        def morning(cycle: int) -> int:
            return max(
                clamp(preferred(0, cycle - age), self.lower[0], self.upper[0]) + weight
                for age, weight in enumerate(self.morning_weights)
                if weight is not None
            )

        @cache
        def evening_bounds(cycle: int) -> tuple[int, int]:
            lower, upper = self.lower[1], self.upper[1]
            for edge in self.edges:
                if edge.source == 0 and edge.target == 1:
                    lower = max(lower, morning(cycle - edge.advance) + edge.weight)
                elif edge.source == 1 and edge.target == 0:
                    upper = min(upper, morning(cycle + edge.advance) - edge.weight)
            return lower, upper

        def evening_base(cycle: int) -> int:
            lower, _ = evening_bounds(cycle)
            upper = min(
                evening_bounds(cycle + age)[1] - weight
                for age, weight in enumerate(self.evening_weights)
                if weight is not None
            )
            return clamp(preferred(1, cycle), lower, upper)

        evening = max(
            evening_base(day - age) + weight
            for age, weight in enumerate(self.evening_weights)
            if weight is not None
        )
        return morning(day), evening

    def occurrences(
        self, days: Iterable[int], preferences: Preferences
    ) -> list[Occurrence]:
        result = []
        for day in days:
            anchors = self.resolve(day, preferences)
            for point in self.points:
                position = point.minute + point.source_day * DAY
                if point.basis != "Clock":
                    position += anchors[ANCHORS.index(point.basis)]
                result.append((day * DAY + position, point.kelvin, point.key))
        return result


def finite_reference(
    points: Sequence[Point],
    anchors: Sequence[Anchor],
    first: int,
    last: int,
    preferences: Preferences,
) -> dict[tuple[str, int], float]:
    days = range(first, last + 2)
    keys = [(name, day) for name in ANCHORS for day in days]
    indices = {key: index + 1 for index, key in enumerate(keys)}
    count = len(keys) + 1
    infinity = float("inf")
    distance = [[infinity] * count for _ in range(count)]
    for index in range(count):
        distance[index][index] = 0

    def bound(source: int, target: int, maximum: float) -> None:
        distance[source][target] = min(distance[source][target], maximum)

    for (name, day), index in indices.items():
        anchor = anchors[ANCHORS.index(name)]
        origin = (day + anchor.source_day) * DAY
        low = origin + (0 if anchor.automatic else anchor.clock)
        high = origin + (DAY - 1 if anchor.automatic else anchor.clock)
        bound(0, index, high)
        bound(index, 0, -low)
    ordered = []
    for day in range(first, last + 1):
        for point in points:
            if point.basis == "Clock":
                ordered.append((0, (day + point.source_day) * DAY + point.minute))
            else:
                ordered.append((indices[point.basis, day], point.minute))
    point = points[0]
    ordered.append(
        (0, (last + 1 + point.source_day) * DAY + point.minute)
        if point.basis == "Clock"
        else (indices[point.basis, last + 1], point.minute)
    )
    for (left, left_offset), (right, right_offset) in pairwise(ordered):
        bound(right, left, right_offset - left_offset - 1)
    for middle in range(count):
        for source in range(count):
            if distance[source][middle] == infinity:
                continue
            for target in range(count):
                distance[source][target] = min(
                    distance[source][target],
                    distance[source][middle] + distance[middle][target],
                )
    if any(distance[index][index] < 0 for index in range(count)):
        raise ValueError("Reference interval is infeasible")

    def pin_edge(source: int, target: int, maximum: float) -> None:
        if maximum >= distance[source][target]:
            return
        left = [distance[index][source] for index in range(count)]
        right = distance[target][:]
        for start in range(count):
            for end in range(count):
                distance[start][end] = min(
                    distance[start][end], left[start] + maximum + right[end]
                )

    result = {}
    for name, day in keys:
        anchor = anchors[ANCHORS.index(name)]
        value = preferences(name, day + anchor.source_day) if anchor.automatic else None
        preferred = (day + anchor.source_day) * DAY + (
            anchor.clock if value is None else value
        )
        index = indices[name, day]
        chosen = max(-distance[index][0], min(preferred, distance[0][index]))
        pin_edge(0, index, chosen)
        pin_edge(index, 0, -chosen)
        result[name, day] = chosen - day * DAY
    return result


def elapsed_minute(nominal: int, change: str) -> int | None:
    if change == "spring":
        if nominal < 120:
            return nominal
        if nominal < 180:
            return None
        return nominal - 60
    if change == "fall":
        return nominal if nominal < 120 else nominal + 60
    raise ValueError("Unknown synthetic clock change")


def actual_points(
    points: Iterable[tuple[int, int]], change: str
) -> list[tuple[int, int]]:
    result = []
    for nominal, kelvin in points:
        elapsed = elapsed_minute(nominal, change)
        if elapsed is not None:
            result.append((elapsed, kelvin))
    return result


def temperature(points: Sequence[tuple[int, int]], instant: int | Fraction) -> Fraction:
    for (start, first), (end, last) in pairwise(points):
        if start <= instant <= end:
            return first + Fraction(instant - start, end - start) * (last - first)
    raise ValueError("The provided occurrences do not bracket the instant")


class ScheduleVerification(unittest.TestCase):
    @override
    def setUp(self) -> None:
        self.anchors = (Anchor(420), Anchor(1140))

    def assert_ordered(self, occurrences: Sequence[Occurrence]) -> None:
        self.assertTrue(
            all(after[0] - before[0] >= 1 for before, after in pairwise(occurrences))
        )

    def test_static_unique_placement(self) -> None:
        schedule = Schedule(
            (
                Point("a", "Clock", 420),
                Point("b", "Morning", -60),
                Point("c", "Morning", 60),
                Point("d", "Clock", 542),
            ),
            self.anchors,
        )
        for preferred in (0, 480, 481, 1439, None):
            self.assertEqual(
                schedule.resolve(0, lambda name, day, preferred=preferred: preferred)[
                    0
                ],
                481,
            )
        self.assertEqual(
            [row[0] for row in schedule.occurrences([0], lambda name, day: None)],
            [420, 421, 541, 542],
        )

    def test_static_insufficient_space(self) -> None:
        with self.assertRaises(ValueError):
            Schedule(
                (
                    Point("a", "Clock", 420),
                    Point("b", "Morning", -60),
                    Point("c", "Morning", 60),
                    Point("d", "Clock", 540),
                ),
                self.anchors,
            )

    def test_duplicate_offsets_and_manual_conflicts(self) -> None:
        for temperature_value in (3000, 4000):
            with self.assertRaises(ValueError):
                Schedule(
                    (
                        Point("a", "Morning", 30, 3000),
                        Point("b", "Morning", 30, temperature_value),
                    ),
                    self.anchors,
                )
        with self.assertRaises(ValueError):
            Schedule(
                (Point("a", "Clock", 420), Point("b", "Morning", 0)),
                (Anchor(420, False), Anchor(1140)),
            )

    def test_offsets_are_bounded_whole_minutes(self) -> None:
        Schedule(
            (Point("a", "Morning", -240), Point("b", "Morning", 240)), self.anchors
        )
        for offset in (-241, 241, 1.5, True):
            with self.assertRaises(ValueError):
                Schedule((Point("a", "Morning", offset),), self.anchors)  # ty: ignore[invalid-argument-type]

    def test_cross_midnight_collision_is_resolved_with_morning_priority(self) -> None:
        schedule = Schedule(
            (Point("m", "Morning", 0, 6500), Point("e", "Evening", 240, 2200)),
            self.anchors,
        )

        def preferences(name: str, day: int) -> int | None:
            if name == "Morning":
                return 120 if day == 0 else 60
            return 1260 if day == 0 else 1200

        self.assertEqual(schedule.resolve(0, preferences), (120, 1259))
        self.assertEqual(schedule.resolve(1, preferences)[0], 60)
        self.assertEqual(schedule.occurrences([0], preferences)[-1][0], 1499)
        self.assert_ordered(schedule.occurrences(range(-3, 4), preferences))

    def test_backup_is_an_adjustable_preference(self) -> None:
        schedule = Schedule(
            (Point("m", "Morning", 0), Point("e", "Evening", 240)),
            (Anchor(60), Anchor(1260)),
        )
        self.assertEqual(schedule.resolve(0, lambda name, day: None), (60, 1259))

    def test_actual_solar_preference_and_backup_switch(self) -> None:
        schedule = Schedule(
            (
                Point("m", "Morning", 0),
                Point("e", "Evening", 0),
                Point("bed", "Clock", 1380),
                Point("late", "Evening", 240),
            ),
            (Anchor(120), Anchor(1320)),
        )

        def preferences(name: str, day: int) -> int | None:
            if day >= 0:
                return None
            return 121 if name == "Morning" else 1320

        self.assertEqual(schedule.resolve(-1, preferences), (121, 1319))
        self.assert_ordered(schedule.occurrences(range(-8, 9), preferences))

    def test_restart_and_evaluation_order_do_not_change_dated_points(self) -> None:
        points = (
            Point("a", "Morning", -240),
            Point("b", "Morning", 240),
            Point("c", "Evening", -240),
            Point("d", "Evening", 240),
        )

        def preferences(name: str, day: int) -> int | None:
            return (day * 977 + (53 if name == "Morning" else 777)) % DAY

        schedule = Schedule(points, self.anchors)
        expected = {day: schedule.resolve(day, preferences) for day in range(-10, 11)}
        for day in reversed(range(-10, 11)):
            self.assertEqual(
                Schedule(points, self.anchors).resolve(day, preferences), expected[day]
            )
        self.assert_ordered(schedule.occurrences(range(-10, 11), preferences))
        first = schedule.occurrences(range(-2, 2), preferences)
        later = schedule.occurrences(range(-1, 3), preferences)
        self.assertEqual(first[len(points) :], later[: -len(points)])

    def test_normalized_cycle_can_use_next_date_morning(self) -> None:
        points = (
            Point("evening", "Evening", -120),
            Point("morning", "Morning", -240),
            Point("late", "Evening", 240),
            Point("wake", "Morning", 0),
        )
        anchors = (Anchor(60, True, 1), Anchor(1320))
        schedule = Schedule(points, anchors)

        def preferences(name: str, day: int) -> int | None:
            return (day * 211 + (60 if name == "Morning" else 1320)) % DAY

        self.assert_ordered(schedule.occurrences(range(-8, 9), preferences))
        reference = finite_reference(points, anchors, -8, 8, preferences)
        self.assertEqual(
            schedule.resolve(0, preferences),
            (reference["Morning", 0], reference["Evening", 0]),
        )

    def test_finite_reference_matches_bounded_resolver(self) -> None:
        layouts = (
            (Point("m", "Morning", 0), Point("e", "Evening", 240)),
            (
                Point("a", "Morning", -240),
                Point("b", "Morning", 240),
                Point("c", "Evening", -240),
                Point("d", "Evening", 240),
            ),
            (
                Point("a", "Morning", -240),
                Point("b", "Evening", -240),
                Point("c", "Morning", 240),
                Point("d", "Evening", 240),
            ),
            (
                Point("m", "Morning", 0),
                Point("e", "Evening", 0),
                Point("fixed", "Clock", 1380),
                Point("late", "Evening", 240),
            ),
        )
        rng = random.Random(20261016)
        for points in layouts:
            schedule = Schedule(points, self.anchors)
            for sample in range(12):
                values = {
                    (name, day): rng.choice((None, 0, 1, 420, 720, 1199, 1438, 1439))
                    for name in ANCHORS
                    for day in range(-30, 31)
                }

                def preferences(
                    name: str,
                    day: int,
                    values: dict[tuple[str, int], int | None] = values,
                ) -> int | None:
                    return values[name, day]

                reference = finite_reference(points, self.anchors, -8, 8, preferences)
                with self.subTest(layout=points, sample=sample):
                    for day in (-1, 0, 1):
                        self.assertEqual(
                            schedule.resolve(day, preferences),
                            (reference["Morning", day], reference["Evening", day]),
                        )
                    self.assert_ordered(schedule.occurrences(range(-8, 9), preferences))

    def test_exhaustive_small_feasible_assignment_oracle(self) -> None:
        points = (
            Point("before_m", "Clock", 120),
            Point("m", "Morning", 0),
            Point("after_m", "Clock", 123),
            Point("before_e", "Clock", 1320),
            Point("e", "Evening", 0),
            Point("after_e", "Clock", 1323),
        )
        schedule = Schedule(points, self.anchors)
        feasible = [
            (m, e)
            for m in range(119, 125)
            for e in range(1319, 1325)
            if 120 < m < 123 and 1320 < e < 1323
        ]
        self.assertEqual(feasible, [(121, 1321), (121, 1322), (122, 1321), (122, 1322)])
        for raw_m, raw_e in product(range(119, 125), range(1319, 1325)):
            expected = min(
                feasible,
                key=lambda pair: (
                    abs(pair[0] - raw_m),
                    pair[0],
                    abs(pair[1] - raw_e),
                    pair[1],
                ),
            )
            self.assertEqual(
                schedule.resolve(
                    0,
                    lambda name, day, raw_m=raw_m, raw_e=raw_e: (
                        raw_m if name == "Morning" else raw_e
                    ),
                ),
                expected,
            )

    def test_spring_omits_points_and_preserves_spacing(self) -> None:
        points = actual_points(
            [(119, 3000), (150, 3500), (180, 4000), (210, 4500)], "spring"
        )
        self.assertEqual(points, [(119, 3000), (120, 4000), (150, 4500)])
        self.assertEqual(temperature(points, Fraction(239, 2)), 3500)

    def test_spring_interpolation_uses_elapsed_minutes(self) -> None:
        points = actual_points([(60, 6000), (240, 3000)], "spring")
        self.assertEqual(points, [(60, 6000), (180, 3000)])
        self.assertEqual(
            [temperature(points, instant) for instant in (90, 120, 150)],
            [5250, 4500, 3750],
        )

    def test_missing_anchor_clock_does_not_remove_valid_offset_point(self) -> None:
        points = actual_points([(150, 3000), (150 + 60, 3600)], "spring")
        self.assertEqual(points, [(150, 3600)])

    def test_repeated_time_uses_first_occurrence_without_replay(self) -> None:
        points = actual_points([(90, 4000), (150, 5000)], "fall")
        self.assertEqual(points, [(90, 4000), (210, 5000)])
        self.assertEqual(temperature(points, 150), 4500)
        points = actual_points([(0, 6000), (240, 3000)], "fall")
        self.assertEqual(
            [temperature(points, instant) for instant in (90, 150)], [5100, 4500]
        )

    def test_all_points_skipped_uses_surrounding_dates(self) -> None:
        points = actual_points(
            [
                (-1310, 4000),
                (-1270, 2500),
                (130, 4000),
                (170, 2500),
                (1570, 4000),
                (1610, 2500),
            ],
            "spring",
        )
        self.assertEqual(
            points, [(-1310, 4000), (-1270, 2500), (1510, 4000), (1550, 2500)]
        )
        self.assertEqual(temperature(points, 120), 3250)

    def test_interpolation_crosses_midnight_without_reset(self) -> None:
        spring = actual_points([(-60, 3000), (420, 5400)], "spring")
        fall = actual_points([(-60, 3000), (420, 5400)], "fall")
        self.assertEqual(spring, [(-60, 3000), (360, 5400)])
        self.assertEqual(fall, [(-60, 3000), (480, 5400)])
        self.assertEqual(temperature(spring, 150), 4200)
        self.assertEqual(temperature(fall, 210), 4200)
        self.assertEqual(
            actual_points([(1439, 3000), (1440, 4000)], "spring"),
            [(1379, 3000), (1380, 4000)],
        )
        self.assertEqual(
            actual_points([(1439, 3000), (1440, 4000)], "fall"),
            [(1499, 3000), (1500, 4000)],
        )

    def test_cycle_indexing_does_not_change_physical_occurrences(self) -> None:
        original = Schedule(
            (
                Point("m1", "Morning", -240),
                Point("m2", "Morning", 240),
                Point("e1", "Evening", -240),
                Point("e2", "Evening", 240),
            ),
            self.anchors,
        )
        rotated = Schedule(
            (
                Point("e1", "Evening", -240),
                Point("e2", "Evening", 240),
                Point("m1", "Morning", -240),
                Point("m2", "Morning", 240),
            ),
            (Anchor(420, True, 1), Anchor(1140)),
        )

        def preferences(name: str, day: int) -> int | None:
            return (day * 811 + (117 if name == "Morning" else 1303)) % DAY

        for day in range(-5, 6):
            self.assertEqual(
                original.resolve(day, preferences)[1],
                rotated.resolve(day, preferences)[1],
            )
            self.assertEqual(
                original.resolve(day + 1, preferences)[0] + DAY,
                rotated.resolve(day, preferences)[0],
            )

    def test_manual_anchor_values_remain_exact(self) -> None:
        points = (Point("m", "Morning", 0), Point("e", "Evening", 0))
        for manual_morning, manual_evening in product((False, True), repeat=2):
            anchors = (
                Anchor(420, not manual_morning),
                Anchor(1140, not manual_evening),
            )
            schedule = Schedule(points, anchors)

            def preferences(name: str, day: int) -> int | None:
                return 1439 if name == "Morning" else 0

            for day in range(-2, 3):
                resolved = schedule.resolve(day, preferences)
                if manual_morning:
                    self.assertEqual(resolved[0], 420)
                if manual_evening:
                    self.assertEqual(resolved[1], 1140)
            self.assert_ordered(schedule.occurrences(range(-2, 3), preferences))

    def test_fixed_minute_capacity(self) -> None:
        points = tuple(Point(str(minute), "Clock", minute) for minute in range(DAY))
        schedule = Schedule(points, self.anchors)
        self.assertEqual(
            [point[0] for point in schedule.occurrences([0], lambda name, day: None)],
            list(range(DAY)),
        )
        with self.assertRaises(ValueError):
            Schedule((*points, Point("duplicate", "Clock", 1439)), self.anchors)

    def test_full_resolution_then_spring_conversion(self) -> None:
        schedule = Schedule(
            (
                Point("before", "Clock", 119, 3000),
                Point("missing", "Morning", 0, 3500),
                Point("after", "Morning", 60, 4500),
            ),
            (Anchor(150, False), Anchor(1140)),
        )
        nominal = [
            (minute, kelvin)
            for minute, kelvin, key in schedule.occurrences([0], lambda name, day: None)
        ]
        self.assertEqual(actual_points(nominal, "spring"), [(119, 3000), (150, 4500)])

    def test_single_point_stays_constant_across_missing_occurrence(self) -> None:
        schedule = Schedule(
            (Point("constant", "Morning", 0, 3400),), (Anchor(150, False), Anchor(1140))
        )
        nominal = [
            (minute, kelvin)
            for minute, kelvin, key in schedule.occurrences(
                range(-1, 2), lambda name, day: None
            )
        ]
        actual = actual_points(nominal, "spring")
        self.assertEqual(actual, [(-1290, 3400), (1530, 3400)])
        self.assertEqual(temperature(actual, 120), 3400)

    def test_dense_dst_boundaries(self) -> None:
        points = [(minute, 4000) for minute in range(DAY)]
        spring = actual_points(points, "spring")
        fall = actual_points(points, "fall")
        self.assertEqual([point[0] for point in spring], list(range(1380)))
        self.assertEqual(
            [point[0] for point in fall], list(range(120)) + list(range(180, 1500))
        )
        self.assertEqual(len(spring), 1380)
        self.assertEqual(len(fall), 1440)


if __name__ == "__main__":
    unittest.main(verbosity=2)
