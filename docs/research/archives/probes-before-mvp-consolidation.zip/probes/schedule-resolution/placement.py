import json
import sys
import unittest
from collections.abc import Sequence
from dataclasses import replace
from statistics import median
from time import perf_counter
from unittest.mock import patch

from editor import EditorVerification as EditorVerification
from editor import anchor_time, insertion_orders, normalize, place, point_time
from verify import ANCHORS, DAY, OFFSET_LIMIT, Anchor, Point, Preferences, Schedule


def ordered_place(
    points: Sequence[Point],
    anchors: Sequence[Anchor],
    selected: Point,
    target: int,
    preferences: Preferences,
) -> Schedule:
    points, anchors = tuple(points), tuple(anchors)
    if type(target) is not int or type(selected.source_day) is not int:
        raise ValueError("Placement uses whole clock minutes and source dates")
    start = normalize(points, anchors) if points else None
    original = next((point for point in points if point.key == selected.key), None)
    if start is not None and original is not None and original.basis == selected.basis:
        if point_time(start, selected.key, selected.source_day, preferences) == target:
            return normalize(
                tuple(
                    replace(point, kelvin=selected.kelvin)
                    if point.key == selected.key
                    else point
                    for point in points
                ),
                anchors,
            )
    if selected.basis == "Clock":
        selected = replace(selected, minute=target % DAY, source_day=target // DAY)
        offsets = [selected.minute]
    elif selected.basis in ANCHORS:
        if start is not None:
            reference = anchor_time(
                start, selected.basis, selected.source_day, preferences
            )
        else:
            anchor = anchors[ANCHORS.index(selected.basis)]
            value = (
                preferences(selected.basis, selected.source_day)
                if anchor.automatic
                else None
            )
            reference = selected.source_day * DAY + (
                anchor.clock if value is None else value
            )
        offsets = sorted(
            range(-OFFSET_LIMIT, OFFSET_LIMIT + 1),
            key=lambda offset: (abs(target - offset - reference), offset),
        )
    else:
        raise ValueError("Unknown point basis")
    others = tuple(point for point in points if point.key != selected.key)
    orders = tuple(insertion_orders(others, selected, target, anchors))
    for offset in offsets:
        for order in orders:
            try:
                candidate = normalize(
                    (*order[:-1], replace(order[-1], minute=offset)), anchors
                )
            except ValueError:
                continue
            if (
                point_time(candidate, selected.key, selected.source_day, preferences)
                == target
            ):
                return candidate
    raise ValueError("No valid placement reaches the requested minute")


def fixtures(count: int, relative: bool) -> tuple[list[Point], tuple[Anchor, Anchor]]:
    anchors = (Anchor(360), Anchor(1140))
    if relative:
        morning = [Point("selected", "Morning", 30)]
        evening = []
        for index in range(1, count):
            if index % 2:
                evening.append(Point(str(index), "Evening", 10 * (index // 2)))
            else:
                morning.append(Point(str(index), "Morning", 60 + 10 * (index // 2)))
        points = morning + evening
    else:
        points = [Point("selected", "Morning", 30), Point("second", "Morning", 120)]
        points += [
            Point(str(index), "Clock", 600 + 13 * index) for index in range(count - 3)
        ]
        points.append(Point("evening", "Evening", 0))
    return points, anchors


class OrderedPlacementTests(unittest.TestCase):
    def test_equivalence_with_exhaustive_reference(self) -> None:
        for automatic in ((False, False), (True, False), (False, True), (True, True)):
            points, anchors = fixtures(3, False)
            anchors = tuple(
                replace(anchor, automatic=flag)
                for anchor, flag in zip(anchors, automatic, strict=True)
            )
            for target in (0, 391, 480, 1380):
                with self.subTest(automatic=automatic, target=target):

                    def preferences(name: str, day: int) -> int | None:
                        return 360 if name == "Morning" else 1140

                    expected = None
                    try:
                        expected = place(
                            points, anchors, points[0], target, preferences
                        )
                    except ValueError:
                        pass
                    if expected is None:
                        with self.assertRaises(ValueError):
                            ordered_place(
                                points, anchors, points[0], target, preferences
                            )
                    else:
                        result = ordered_place(
                            points, anchors, points[0], target, preferences
                        )
                        self.assertEqual(
                            (result.points, result.anchors),
                            (expected.points, expected.anchors),
                        )

    def test_insertion_and_fixed_point_equivalence(self) -> None:
        points, anchors = fixtures(3, False)

        def preferences(name: str, day: int) -> int | None:
            return 360 if name == "Morning" else 1140

        for selected, target in (
            (Point("new", "Morning", 0), 391),
            (Point("new", "Clock", 0), 1380),
            (points[0], 390),
        ):
            expected = place(points, anchors, selected, target, preferences)
            result = ordered_place(points, anchors, selected, target, preferences)
            self.assertEqual(
                (result.points, result.anchors), (expected.points, expected.anchors)
            )


def benchmark() -> None:
    rows = []

    def preferences(name: str, day: int) -> int | None:
        return 360 if name == "Morning" else 1140

    for relative in (False, True):
        for count in (3, 10, 30):
            points, anchors = fixtures(count, relative)
            for action, selected in (
                ("drag", points[0]),
                ("insert", Point("new", "Morning", 0)),
            ):
                samples = []
                for _ in range(3):
                    start = perf_counter()
                    result = ordered_place(points, anchors, selected, 391, preferences)
                    samples.append((perf_counter() - start) * 1000)
                    if point_time(result, selected.key, 0, preferences) != 391:
                        raise AssertionError("Placement missed target")
                rows.append(
                    dict(
                        relative=relative,
                        count=count,
                        action=action,
                        median_ms=median(samples),
                    )
                )
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["--benchmark"]:
        benchmark()
    else:
        with patch("editor.place", ordered_place):
            unittest.main()
