//! Compare local solar events with independently recorded USNO results.

#[cfg(test)]
mod tests;
