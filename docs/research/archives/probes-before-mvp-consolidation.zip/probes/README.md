# Research probes

Probes are isolated experiments that establish dependency capabilities and limitations before Circadia relies on them. They can contain automated tests, but their results apply only to the recorded versions, environment, and exercised behavior. The [spec](../docs/specs/SPEC.md) defines product requirements; the [research index](../docs/research/README.md) links the supporting analysis.

Solar calculation, location acquisition, and adjustment of solar-based reference times to preserve curve-point order support post-MVP research. The current MVP uses manual Wake and Bedtime clocks; each temperature point is timed by an offset from one of those clocks. Windows clock conversion and native graph controls remain relevant; the probe fixtures do not define application behavior.

## Available probes

| Probe | Research question | Validation summary |
| :-- | :-- | :-- |
| [Published Reactor UI](windows-reactor/README.md) | Can published Reactor support native settings controls and a draggable temperature graph? | Unit tests and native UI checks for editing time/temperature points, including insertion and dragging at 100% scaling. |
| [Night Light runtime](nightlight-runtime/README.md) | Do public native operations and Windows controls store the requested temperatures at a useful cadence? | Fifteen direct operations, CLI readback, a timed reversal, native slider response, and restoration pass. Physical display output is an accepted assumption. |
| [Development Reactor lifecycle](windows-reactor/development/README.md) | Can one Reactor process keep a tray icon and application state after settings closes? | Tray-only startup, settings close/reopen, preserved state, native handle access, explicit exit, and execution from a copied deployment directory. Activation uses a synthetic callback. The graph on the pinned development revision, native executable dialog, location request, and foreground lookup also pass. |
| [Daily schedule resolution](schedule-resolution/README.md) | Can fixed clock points and bounded offsets from daily Morning/Evening reference times preserve their order across changing dates without annual validation? | Twenty-three resolver tests, thirty-six editor tests, and ten Windows clock tests cover a separately implemented comparison solver over a bounded date range, conversion of repeating point sequences with assigned dates, insertion, dragging, current-day anchor changes, cross-midnight constraints, synthetic clock changes, and installed Windows conversion rules. Eight combined solar/date/resolver tests and actual host time-setting changes pass. The [ordered placement search](schedule-resolution/README.md#ordered-placement-search) passes 38 tests. Native editor bindings remain unverified. |
| [Local solar calculation](solar-calculation/README.md) | Can a local Rust library find all rise/set events on the selected civil date and support daily anchor preferences? | Six tests cover 36 saved United States Naval Observatory (USNO) cases, missing and repeated events, remote clock zones, invalid inputs, and synthetic preference selection and midnight rounding. |

Each probe's README records its dependency source, validation date and environment, commands, side effects, and untested cases. Read that summary before inspecting source or running the experiment. Probe builds and interactive scripts are separate from default application checks.

## Python validation

Python probes use CPython 3.15. Shared [configuration](pyproject.toml) enables Ruff correctness, import, modernization, and annotation rules, plus ty checks for Python 3.15 on Windows. The [recipes](justfile) pin Ruff 0.17.1 and ty 0.0.89 and run both through `uvx`.

Run from the repository root in MSYS2 Bash on Windows, with `uv` and `just` installed:

```bash
just --justfile probes/justfile python-check
just --justfile probes/justfile python-test
```

`python-check` runs lint, formatting verification, and type checking across Python probes, including scripts that require explicit invocation to change host settings. It does not execute those scripts. `python-test` runs the resolver, editor, ordered-placement, and read-only Windows clock suites. `python-format` applies Ruff formatting. These commands remain separate from application checks.

`python-integration` builds the existing solar fixture binary with its locked Cargo dependencies and runs the read-only solar/date/resolver suite. It requires the Rust stable toolchain. The host time-zone exercise remains a separate command documented in the [schedule probe](schedule-resolution/README.md#combined-calculation-and-host-settings).

Keep function parameters and return values annotated. Use concrete types for callbacks, native structure fields, and external data. Limit type-check suppressions to intentional invalid-input fixtures; explain any lint suppression at its use. Run the shared checks and affected test suites after changing Python probes.

## Adding or retiring a probe

Give each independently runnable experiment a README and add it to this index. Related experiments can share a parent directory; the Reactor probes use separate manifests and lockfiles to distinguish published and development APIs.

Keep reproducible source and required assets in version control. Exclude generated binaries, build directories, and routine run output. When application tests replace a probe's useful coverage, update the linked research to identify the replacement before removing the redundant probe.
